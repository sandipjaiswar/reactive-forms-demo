import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone:true,
  imports: [RouterOutlet, CommonModule, ReactiveFormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected title = 'reactive-forms-demo';
  userFrom: FormGroup<{
    name: FormControl<string | null>;
    email: FormControl<string | null>;
    password: FormControl<string | null>;
  }>;
  constructor(private fb: FormBuilder){
       this.userFrom = this.fb.group({
        name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]]
       })
  }

  ngSubmit(){
    if(this.userFrom.valid){
       console.log('Submitted',this.userFrom.value); 
       alert('Form submitted successfully!');
       this.userFrom.reset();
    }else{
      this.userFrom.markAllAsTouched(); // to show error
    }
  }
}
